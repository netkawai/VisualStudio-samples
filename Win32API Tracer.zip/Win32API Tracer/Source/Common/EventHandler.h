#ifndef __EVENTHANDLER_H_105D52D8_13EC_4ea3_A86B_076B726541EB_
#define __EVENTHANDLER_H_105D52D8_13EC_4ea3_A86B_076B726541EB_

#include <AtlColl.h>

namespace OIL
{
	class CEventSource;	//Forward declaration

	class CEventHandlerArgs
	{
	public:
		CEventHandlerArgs() {}
		virtual ~CEventHandlerArgs() { }
	};

	/// <Summary>
	/// For Class-based Event Subscriptions, a class can receive
	/// events only if it is derived from CEventReceiver.
	/// <para> See CEvent for sample usage.</para>
	/// </Summary>
	class CEventReceiver
	{
	protected:
		// Protected constructor. CEventReceiver objects cannot be created directly.
		// This Class should be inherited.
		CEventReceiver() {}		

		// Protected destructor. 
		// No need to declare as virtual because delete can't be applied on CEventReceiver pointers.
		~CEventReceiver() { }
	};

	/// <Summary>
	/// Class for Event Subscription Function Objects.
	/// </Summary>
	class IEventFunctor
	{
	public:
		virtual ~IEventFunctor() { }
		virtual void operator()(CEventReceiver* pReceiver, const CEventSource* pSender, CEventHandlerArgs* pArgs) = 0;
	};

	/// <Summary>
	/// A Receiver can Subscribe for an Event only once.
	/// If a Receiver requests a second subscription for the same Event,
	/// its previous subscription would be replaced with the new subscription.
	///
	/// A Receiver can subscribe for as many different events as it wants. 
	/// But for each, only once.
	///
	/// And an Event can have as many Receivers as it likes.
	/// </Summary>
	/// <example>Following Snippet demonstrates sample usage.
	/// <code>
	/// class MySender : public CEventSource
	/// {
	///		public:
	///		CEvent m_Event;
	///		...
	///		void MyFunction()
	///		{
	///			...
	///			RaiseEvent(&m_Event, &CEventHandlerArgs());	// Invokes the Event
	///			...
	///		}
	///		...
	///	};
	///	class MyReceiver: public CEventReceiver
	///	{
	///		MyClass	MySenderObject;
	///	public:
	///		MyReceiver()
	///		{
	///			// Subscribe for the Event
	///			MySenderObject.m_Event.Subscribe(this, & MyReceiver::EventReceptionFunc);
	///		}
	///		void EventReceptionFunc(const CEventSource* pSrc, CEventHandlerArgs* pArgs)
	///		{
	///			// Code for Handling the Event
	///		}
	///	};
	/// </code>
	/// </example>
	class CEvent
	{
		/// <Summary>
		/// Implements IEventFunctor for Handling Class-based Subscriptions.
		/// </Summary>
		template<typename TClass>
		class CClassFunctor : public IEventFunctor
		{
			typedef void (TClass::*FuncType)(const CEventSource* pSender, CEventHandlerArgs* pArgs);

			FuncType m_pFunc;

			CClassFunctor(FuncType pFunc) : m_pFunc(pFunc) { }

			inline void operator()(CEventReceiver* pReceiver, const CEventSource* pSender, CEventHandlerArgs* pArgs)
			{
				(((TClass*)pReceiver)->*m_pFunc)(pSender, pArgs);
			}

			friend class CEvent; // Only CEvent Objects can use the CClassFunctor Objects
		};

		typedef ATL::CMapToAutoPtr<CEventReceiver*, IEventFunctor> CLASS_HANDLER_MAP;
		typedef void (*STATICHANDLER)(const CEventSource*, CEventHandlerArgs*);
		typedef ATL::CAtlList<STATICHANDLER> STATIC_HANDLER_LIST;

		CLASS_HANDLER_MAP	m_ClassSubscribers;
		STATIC_HANDLER_LIST	m_StaticSubscribers;

		/// <Summary>
		/// Events can be Invoked only through CEventSource::RaiseEvent()
		/// </Summary>
		void Invoke(const CEventSource* pSender, CEventHandlerArgs* pArgs)
		{
			POSITION pos = m_ClassSubscribers.GetStartPosition();

			// Invoke operator() on each of the CClassFunctor Objects
			while( NULL != pos)
			{
				(*m_ClassSubscribers.GetValueAt(pos))(m_ClassSubscribers.GetKeyAt(pos), pSender, pArgs);
				m_ClassSubscribers.GetNext(pos);
			}

			pos = m_StaticSubscribers.GetHeadPosition();

			// Invoke operator() on each of the CStaticFunctor Objects
			while(NULL != pos)
				(*m_StaticSubscribers.GetNext(pos))(pSender, pArgs);
		}

		friend class CEventSource;

		CEvent& operator = (const CEvent& );	// Prohibit Assignment

		CEvent(const CEvent& );		// Prohibit Copy Constructor

	public:
		inline CEvent() { }

		inline ~CEvent() {	}

		typedef ATL::CAutoPtr<IEventFunctor> IEventFunctorPtr;

		/// <Summary>
		/// Creates an IEventFunctor object for the given function and
		/// subcribes it to be called upon the given object whenever the event
		/// is raised.
		/// Duplicates or Multiple Subscriptions are not allowed.
		/// If the Receiver object already has a subscription for this event,
		/// the old subscription is removed before adding the new subcription.
		/// </Summary>
		template<typename TClass>
		inline void Subscribe(TClass* pReceiver, void (TClass::*lpfnHandler)(const CEventSource*, CEventHandlerArgs* ))
		{
			ATLASSERT(pReceiver != NULL);

			Subscribe(pReceiver, IEventFunctorPtr(new CClassFunctor<TClass>(lpfnHandler)));
		}

		/// <Summary>
		/// Takes ownership of the supplied IEventFunctor pointer.
		/// Assumes that it is allocated with new, and calls delete 
		/// automatically upon it when going out of scope.
		/// Duplicate or Multiple Subscriptions are not allowed.
		/// If the Receiver object already has a subscription for this event,
		/// the old subscription is removed before adding the new subcription.
		/// </Summary>
		template<typename TReceiverClass>
		inline void Subscribe(TReceiverClass* pReceiver, ATL::CAutoPtr<IEventFunctor>& spFunctor)
		{
			ATLASSERT(pReceiver != NULL && spFunctor.m_p != NULL);

			m_ClassSubscribers[pReceiver] = spFunctor;
		}

		/// <Summary>
		/// Subscribes the given Function to be called whenever the event is raised.
		/// Duplicates are not Allowed. 
		/// If the given Function is already a subscriber, it would not be added again.
		/// </Summary>
		inline void Subscribe(void (*lpfnHandler)(const CEventSource*, CEventHandlerArgs*))
		{
			ATLASSERT(NULL != lpfnHandler);

			if( NULL == m_StaticSubscribers.Find(lpfnHandler) )	// Do not Add if Already Exists
				m_StaticSubscribers.AddTail( lpfnHandler );
		}

		/// <Summary>
		/// UnSubscribes the given Function from being called.
		/// Nothing Happens if the given Function is not a Subscriber.
		/// </Summary>
		inline void UnSubscribe(void (*lpfnHandler)(const CEventSource*, CEventHandlerArgs*))
		{
			POSITION pos = m_StaticSubscribers.Find(lpfnHandler);
			if( NULL != pos )
				m_StaticSubscribers.RemoveAt(pos);
		}

		/// <Summary>
		/// UnSubscribes the pReceiver from the Subscription.
		/// Nothing Happens if the supplied pReceiver object is not a Subscriber.
		/// </Summary>
		template<typename TReceiverClass>
		inline void UnSubscribe(TReceiverClass* pReceiver)
		{
			m_ClassSubscribers.RemoveKey(pReceiver);
		}

		/// <Summary>
		/// UnSubscribes all receivers. SubscriberCount() would become Zero.
		/// </Summary>
		inline void UnSubscribeAll()
		{
			// Remove Static Subscribers
			m_StaticSubscribers.RemoveAll();
			// Remove Class-based Subscribers
			m_ClassSubscribers.RemoveAll();
		}

		/// <Summary>
		/// Gives the number of active Subcriptions for this event.
		/// It includes the Class-based Subscriptions as well the Function-based ones.
		/// </Summary>
		inline size_t SubscriberCount() const	
		{	
			return m_ClassSubscribers.GetCount() + m_StaticSubscribers.GetCount();
		}
	};

	/// <Summary>
	/// Only CEventSource derived classes can raise events.
	/// <para>See CEvent for sample usage.</para>
	/// </Summary>
	class CEventSource
	{	
	protected:
		// CEventSource objects cannot be created directly due to the protected constructor. 
		// This class can Only be Inherited.
		CEventSource() {}

		// Protected destructor. 
		// No need to declare as virtual because delete can't be applied on CEventSource pointers.
		~CEventSource() { }

		/// <Summary>
		/// Invokes the Event.
		/// </Summary>
		inline void RaiseEvent(CEvent* pEvent, CEventHandlerArgs* pArgs)
		{
			ATLASSERT(pEvent != NULL);

			pEvent->Invoke(this, pArgs);
		}
	};

	/// <Summary>
	/// An event that can be invoked by itself
	/// </Summary>
	class CInvokableEvent : protected CEventSource, public CEvent
	{
	public:
		inline void RaiseEvent(CEventHandlerArgs* pArgs)
		{
			CEventSource::RaiseEvent(this, pArgs);
		}
	};

}	// namespace OIL

#endif	// __EVENTHANDLER_H_105D52D8_13EC_4ea3_A86B_076B726541EB_