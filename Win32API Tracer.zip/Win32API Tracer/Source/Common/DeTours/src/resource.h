//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by detoured.rc
//
#define VFFF_ISSHAREDFILE               0x0001
#define VFF_CURNEDEST                   0x0001
#define VIFF_FORCEINSTALL               0x0001
#define VS_VERSION_INFO                 1
#define VFF_FILEINUSE                   0x0002
#define VIFF_DONTDELETEOLD              0x0002
#define VFF_BUFFTOOSMALL                0x0004
#define VS_USER_DEFINED                 100

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
