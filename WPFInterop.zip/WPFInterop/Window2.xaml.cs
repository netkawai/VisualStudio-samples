using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFInterop
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>

    public partial class Window2 : System.Windows.Window
    {

        public Window2()
        {
            InitializeComponent();

            this.Loaded += new RoutedEventHandler(Window2_Loaded);

        }

        void Window2_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Forms.WebBrowser browser = new System.Windows.Forms.WebBrowser();
            browser.Navigate("http://www.youtube.com");
            browser.Width = 700;
            browser.Height = 500;

            _host.Child = browser;
        }

    }
}