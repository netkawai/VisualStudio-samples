using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WPFInterop.Interop
{
    public partial class InteropForm : Form
    {
        public InteropForm()
        {
            InitializeComponent();
        }

        private void InteropForm_Load(object sender, EventArgs e)
        {

        }
    }
}