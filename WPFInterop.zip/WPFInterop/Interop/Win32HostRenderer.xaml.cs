using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

using Winforms = System.Windows.Forms;
using GDI = System.Drawing;

using System.Runtime;
using System.Runtime.InteropServices;


namespace WPFInterop.Interop
{
    public partial class Win32HostRenderer : System.Windows.Controls.UserControl
    {
        [DllImport("user32.dll")]
        private static extern bool PrintWindow(IntPtr hwnd, IntPtr hdcBlt, uint nFlags);
     
        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);
        
        [DllImport("Kernel32.dll", EntryPoint = "RtlMoveMemory")]
        private static extern void CopyMemory(IntPtr Destination, IntPtr Source, int Length);

        private DispatcherTimer     _rendererTimer;
        private int                 _rendererInterval = 33;

        private InteropForm         _interopForm;
        private Winforms.Control    _winformControl;

        private BitmapSource        _bitmapSource;
        private BitmapBuffer        _bitmapSourceBuffer;

        private GDI.Bitmap          _gdiBitmap;
        private GDI.Graphics        _gdiBitmapGraphics;
        private IntPtr              _hGDIBitmap;


        public Win32HostRenderer()
        {
            InitializeComponent();
        }

        private void InitializeInteropForm()
        {
            if (_winformControl == null) return;

            if (_interopForm != null)
            {
                TearDownInteropForm();
            }
            
            _interopForm = new InteropForm();
            _interopForm.Opacity = 0.01;
            _interopForm.Controls.Add(_winformControl);
            _interopForm.Width = _winformControl.Width;
            _interopForm.Height = _winformControl.Height;
        }

        private void TearDownInteropForm()
        {
            if (_interopForm == null) return;
            _interopForm.Hide();
            _interopForm.Close();
            _interopForm.Dispose();
            _interopForm = null;
        }

        private void InitializeRendererTimer()
        {
            TearDownRenderTimer();

            _rendererTimer = new DispatcherTimer();
            _rendererTimer.Interval = new TimeSpan(0, 0, 0, 0, _rendererInterval);
            _rendererTimer.Tick += new EventHandler(_rendererTimer_Tick);
            _rendererTimer.Start();
        }

        void _rendererTimer_Tick(object sender, EventArgs e)
        {
            RenderWinformControl();
        }

        private void TearDownRenderTimer()
        {
            if (_rendererTimer == null) return;

            _rendererTimer.IsEnabled = false;

        }
        private void RegisterEventHandlers()
        {
            Window currentWindow = Window.GetWindow(this);
            currentWindow.LocationChanged += new EventHandler(delegate(object sender, EventArgs e)
            {
                PositionInteropFormOverRender();
            });

           
            currentWindow.SizeChanged += new SizeChangedEventHandler(delegate(object sender, SizeChangedEventArgs e)
            {
                PositionInteropFormOverRender();
            });

            currentWindow.Deactivated += new EventHandler(delegate(object sender, EventArgs e)
            {
                //_interopForm.Opacity = 0;
            });

            currentWindow.Activated += new EventHandler(delegate(object sender, EventArgs e)
            {
               // _interopForm.Opacity = 0.01;
            });

            currentWindow.StateChanged += new EventHandler(delegate(object sender, EventArgs e)
            {
                PositionInteropFormOverRender();
            });


            _interopRenderer.SizeChanged += new SizeChangedEventHandler(delegate(object sender, SizeChangedEventArgs e)
            {
                PositionInteropFormOverRender();
            });
        }



        private void PositionInteropFormOverRender()
        {
            if (_interopForm == null) return;
            Window currentWindow = Window.GetWindow(this);

            Point interopRenderScreenPoint = _interopRenderer.PointToScreen(new Point());

            _interopForm.Left = (int)interopRenderScreenPoint.X;
            _interopForm.Top = (int)interopRenderScreenPoint.Y;

            int width = 0;

            if ((int)_interopRenderer.ActualWidth > (int)currentWindow.Width)
            {
                width = (int)currentWindow.Width;
            }
            else
            {
                width = (int)_interopRenderer.ActualWidth;
            }

            if ((int)currentWindow.Width < width) 
                            width = (int)currentWindow.Width;

            _interopForm.Width = width;
        }

        private void InitializeBitmap()
        {
            if (_bitmapSource == null)
            {
                TearDownBitmap();
            }

            int interopRenderWidth = _winformControl.Width;
            int interopRenderHeight = _winformControl.Height;
            int bytesPerPixel = 4;

            int totalPixels = interopRenderWidth * interopRenderHeight * bytesPerPixel;

            byte[] dummyPixels = new byte[totalPixels];

            _bitmapSource = BitmapSource.Create(interopRenderWidth, 
                                        interopRenderHeight, 
                                        96, 
                                        96, 
                                        PixelFormats.Bgr32, 
                                        null,
                                        dummyPixels,
                                        interopRenderWidth * bytesPerPixel);

            _interopRenderer.Source = _bitmapSource;

            _bitmapSourceBuffer = new BitmapBuffer(_bitmapSource);

            _gdiBitmap = new GDI.Bitmap(_winformControl.Width,
                                        _winformControl.Height, 
                                        GDI.Imaging.PixelFormat.Format32bppRgb);

            _hGDIBitmap = _gdiBitmap.GetHbitmap();

            _gdiBitmapGraphics = GDI.Graphics.FromImage(_gdiBitmap);
        }

        private void TearDownBitmap()
        {
            _bitmapSource = null;
            _bitmapSourceBuffer = null;

            if (_gdiBitmap != null)
            {
                _gdiBitmap.Dispose();
            }

            if (_gdiBitmapGraphics != null)
            {
                _gdiBitmapGraphics.Dispose();
            }

            if (_hGDIBitmap != IntPtr.Zero)
            {
                DeleteObject(_hGDIBitmap);
            }
        }

        private void InitializeWinformControl()
        {
            InitializeInteropForm();
            InitializeBitmap();
            RegisterEventHandlers();
            
            PositionInteropFormOverRender();
            _interopForm.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            
            
            _interopForm.Show();
            InitializeRendererTimer();
            
        }

        public Winforms.Control Child
        {
            get { return _winformControl; }
            set
            {
                _winformControl = value;
                InitializeWinformControl();
            }
        }

        private void RenderWinformControl()
        {
            PaintWinformControl(_gdiBitmapGraphics, _winformControl);

            GDI.Rectangle lockRectangle = new GDI.Rectangle(0, 
                                                            0, 
                                                            _gdiBitmap.Width, 
                                                            _gdiBitmap.Height);

            GDI.Imaging.BitmapData bmpData = _gdiBitmap.LockBits(lockRectangle, 
                                                            GDI.Imaging.ImageLockMode.ReadOnly, 
                                                            GDI.Imaging.PixelFormat.Format32bppRgb);
            System.IntPtr bmpScan0 = bmpData.Scan0;

            CopyMemory(_bitmapSourceBuffer.BufferPointer, 
                       bmpScan0,
                       (int)_bitmapSourceBuffer.BufferSize);

            _gdiBitmap.UnlockBits(bmpData);

            _interopRenderer.InvalidateVisual(); 
        }
                
        private void PaintWinformControl(GDI.Graphics graphics, Winforms.Control control)
        { 
            IntPtr hWnd = control.Handle;
            IntPtr hDC = graphics.GetHdc();

            PrintWindow(hWnd, hDC, 0);
           
            graphics.ReleaseHdc(hDC);
        }
    }
}