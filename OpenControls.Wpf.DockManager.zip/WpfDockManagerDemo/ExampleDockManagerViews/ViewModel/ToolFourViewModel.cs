﻿namespace ExampleDockManagerViews.ViewModel
{
    public class ToolFourViewModel : DummyViewModel
    {
        public ToolFourViewModel()
        {
            Title = "Tool Four View Model";
        }
    }
}
