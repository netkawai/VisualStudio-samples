﻿namespace ExampleDockManagerViews.ViewModel
{
    public class DocumentTwoViewModel : DummyViewModel
    {
        public DocumentTwoViewModel()
        {
            Title = "Document Two View Model";
        }
    }
}
