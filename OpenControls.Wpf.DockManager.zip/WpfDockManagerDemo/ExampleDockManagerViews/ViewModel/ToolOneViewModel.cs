﻿namespace ExampleDockManagerViews.ViewModel
{
    public class ToolOneViewModel : DummyViewModel
    {
        public ToolOneViewModel()
        {
            Title = "Tool One View Model";
        }
    }
}
