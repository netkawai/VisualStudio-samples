﻿namespace ExampleDockManagerViews.ViewModel
{
    public class ToolThreeViewModel : DummyViewModel
    {
        public ToolThreeViewModel()
        {
            Title = "Tool Three View Model";
        }
    }
}
