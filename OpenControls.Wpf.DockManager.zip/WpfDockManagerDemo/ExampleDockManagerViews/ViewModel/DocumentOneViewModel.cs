﻿namespace ExampleDockManagerViews.ViewModel
{
    public class DocumentOneViewModel : DummyViewModel
    {
        public DocumentOneViewModel()
        {
            Title = "Document One View Model";
        }
    }
}
