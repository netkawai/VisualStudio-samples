﻿namespace ExampleDockManagerViews.ViewModel
{
    public class ToolTwoViewModel : DummyViewModel
    {
        public ToolTwoViewModel()
        {
            Title = "Tool Two View Model";
        }
    }
}
