﻿namespace ExampleDockManagerViews.ViewModel
{
    public class DocumentThreeViewModel : DummyViewModel
    {
        public DocumentThreeViewModel()
        {
            Title = "Document Three View Model";
        }
    }
}
