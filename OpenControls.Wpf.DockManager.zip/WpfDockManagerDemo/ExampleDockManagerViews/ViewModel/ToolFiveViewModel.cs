﻿namespace ExampleDockManagerViews.ViewModel
{
    public class ToolFiveViewModel : DummyViewModel
    {
        public ToolFiveViewModel()
        {
            Title = "Tool Five View Model";
        }
    }
}
