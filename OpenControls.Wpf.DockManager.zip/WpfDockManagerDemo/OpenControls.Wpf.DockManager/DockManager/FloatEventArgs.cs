﻿namespace WpfOpenControls.DockManager
{
    internal class FloatEventArgs : System.EventArgs
    {
        public bool Drag { get; set; }
    }
}
