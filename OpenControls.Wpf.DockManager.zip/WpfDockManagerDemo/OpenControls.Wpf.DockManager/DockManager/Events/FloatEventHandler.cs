﻿namespace OpenControls.Wpf.DockManager.Events
{
    [System.Runtime.InteropServices.ComVisible(true)]
    internal delegate void FloatEventHandler(object sender, FloatEventArgs e);
}
