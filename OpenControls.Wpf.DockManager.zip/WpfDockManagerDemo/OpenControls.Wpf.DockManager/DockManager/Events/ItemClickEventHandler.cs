﻿namespace OpenControls.Wpf.DockManager.Events
{
    [System.Runtime.InteropServices.ComVisible(true)]
    internal delegate void ItemClickEventHandler(object sender, ItemClickEventArgs e);
}
