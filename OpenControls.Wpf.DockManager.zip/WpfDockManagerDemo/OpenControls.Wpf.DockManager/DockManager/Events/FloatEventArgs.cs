﻿namespace OpenControls.Wpf.DockManager.Events
{
    internal class FloatEventArgs : System.EventArgs
    {
        public bool Drag { get; set; }
    }
}
