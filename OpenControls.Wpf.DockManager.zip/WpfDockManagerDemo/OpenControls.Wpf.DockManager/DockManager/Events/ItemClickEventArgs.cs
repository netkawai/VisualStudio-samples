﻿namespace OpenControls.Wpf.DockManager.Events
{
    internal class ItemClickEventArgs : System.EventArgs
    {
        public Controls.ToolListBox ToolListBox { get; set; }
    }
}
