﻿namespace OpenControls.Wpf.DockManager.Events
{
    [System.Runtime.InteropServices.ComVisible(true)]
    internal delegate void TabClosedEventHandler(object sender, TabClosedEventArgs e);
}
