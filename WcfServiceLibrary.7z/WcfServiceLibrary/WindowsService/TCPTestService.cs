﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace WindowsService
{
    public partial class TCPTestService : ServiceBase
    {
        internal static ServiceHost myServiceHost = null;
        internal static ServiceHost myServiceForServer = null;
        public TCPTestService()
        {
            InitializeComponent();
        }



        protected override void OnStart(string[] args)
        {
            try
            {
                if (myServiceForServer != null)
                {
                    myServiceForServer.Close();
                }
                myServiceForServer = new ServiceHost(typeof(WcfServiceLibraryForServerUI.Service1));
                myServiceForServer.Open();

                if (myServiceHost != null)
                {
                    myServiceHost.Close();
                }
                myServiceHost = new ServiceHost(typeof(WcfServiceLibrary.TcpService));
                myServiceHost.Open();

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        protected override void OnStop()
        {
            if (myServiceHost != null)
            {
                myServiceHost.Close();
                myServiceHost = null;
            }
            if (myServiceForServer != null)
            {
                myServiceForServer.Close();
                myServiceForServer = null;
            }

        }
    }
}
