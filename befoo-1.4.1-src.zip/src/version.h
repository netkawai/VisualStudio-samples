/*
 * Copyright (C) 2009-2014 TSUBAKIMOTO Hiroya <z0rac@users.sourceforge.jp>
 *
 * This software comes with ABSOLUTELY NO WARRANTY; for details of
 * the license terms, see the LICENSE.txt file included with the program.
 */
#define APP_NAME               "befoo"
#define APP_VERSION            "1.4.1"
#define APP_VERSION_BINARY     1,4,1,0
#define APP_COPYRIGHT          "(C) 2009-2014 TSUBAKIMOTO Hiroya"
