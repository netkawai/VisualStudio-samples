// ModuleCollection.h: interface for the ModuleCollection class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MODULECOLLECTION_H__4F808F6B_DB3F_4094_BEBD_61EB1B025056__INCLUDED_)
#define AFX_MODULECOLLECTION_H__4F808F6B_DB3F_4094_BEBD_61EB1B025056__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class ModuleCollection  
{
public:
	ModuleCollection();
	virtual ~ModuleCollection();

};

#endif // !defined(AFX_MODULECOLLECTION_H__4F808F6B_DB3F_4094_BEBD_61EB1B025056__INCLUDED_)
