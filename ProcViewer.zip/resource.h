//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ProcessViewer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PROCESSVIEWER_DIALOG        102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP_IMAGES               133
#define IDR_DLGMENU                     134
#define IDR_ACCEL_MENU                  139
#define IDD_DIALOG_SEARCH               141
#define IDB_BITMAP_SORTDESC             155
#define IDB_BITMAP_SORTASC              156
#define IDD_DIALOG1                     157
#define IDD_DIALOG_OPTIONS              159
#define IDD_DIALOG_PROCESS_DETAILS_OPTIONS 160
#define IDD_DIALOG_MODULE_DETAILS_DIALOG 161
#define IDD_DIALOG_GENERALOPTIONS       162
#define IDR_MENU_PROCESS_PRIORITY       167
#define IDR_MENU_PROCESS_UTILS          167
#define IDD_PRIVILEGE_MGR               170
#define IDC_TREE_PROCESS                1000
#define IDC_LIST_PROCESSMODULES         1001
#define IDC_EDIT1                       1002
#define IDC_EDIT_SRCH_STRING            1002
#define IDC_LIST_MODULESYMBOLS          1002
#define IDC_RADIO_DLL                   1004
#define IDC_RADIO_PROCESS               1005
#define IDC_BUTTON_GO                   1006
#define IDC_OK                          1006
#define IDC_TREE_PROCESSDETAILS         1007
#define IDC_PROGRESS_LOAD               1008
#define IDC_TAB1                        1010
#define IDC_TAB_OPTION                  1010
#define IDC_CHECK1                      1011
#define IDC_CHECK_SIZE                  1011
#define IDC_CHECK_INDEX                 1011
#define IDC_CHECK_PROMPTBEFOREKILL      1011
#define IDC_CHECK2                      1012
#define IDC_CHECK_PROCTIMES             1012
#define IDC_CHECK_MODULENAME            1012
#define IDC_CHECK3                      1013
#define IDC_CHECK_FILETIMES             1013
#define IDC_CHECK_MODULEPATH            1013
#define IDC_CHECK4                      1014
#define IDC_CHECK_MEMINFO               1014
#define IDC_CHECK_LOADADDRESS           1014
#define IDC_CHECK5                      1015
#define IDC_CHECK_PROCESS_TYPE          1015
#define IDC_CHECK_IMAGESIZE             1015
#define IDC_CHECK6                      1016
#define IDC_CHECK_HWND                  1016
#define IDC_CHECK_ENTRYPOINT            1016
#define IDC_CHECK7                      1017
#define IDC_CHECK_VERSION               1017
#define IDC_CHECK8                      1018
#define IDC_CHECK_GDIINFO               1018
#define IDC_CHECK_FILESIZE              1018
#define IDC_CHECK_COMPANY               1019
#define IDC_BUTTON_TOGGLE               1019
#define IDC_CHECK_DESCRIPTION           1020
#define IDC_CHECK_PROCESSPRIORITY       1020
#define IDC_CHECK_PROCESSIOCOUNTERS     1021
#define IDC_HOTKEY1                     1021
#define IDC_CHECK9                      1022
#define IDC_CHECK_PROCESSPRIVILEGES     1022
#define IDC_COMBOBOXEX1                 1023
#define IDC_LIST_PRIVILEGE_COLLECTION   1024
#define ID_BUTTON_REFRESH               1025
#define ID_BUTTON_SAFELIST              1026
#define ID_BUTTON_DISABLEALL            1026
#define IDC_BUTTON_ENABLE_ALL           1027
#define IDC_BUTTON_REMOVE_ALL_PRIVILEGES 1028
#define IDC_BUTTON_REMOVE_ALL           1028
#define ID_OPTIONS_REFRESH              32773
#define ID_OPTIONS_SWAPLAYOUT           32774
#define ID_OPTIONS_EXIT                 32775
#define ID_OPTIONS_ABOUT                32776
#define ID_OPTIONS_SHOWPATH             32778
#define ID_OPTIONS_ENABLEDEPENDS        32779
#define ID_SP_MODULE_COUNT              32780
#define ID_OPTIONS_SEARCH               32781
#define ID_OPTIONS_SETTINGS             32782
#define ID_OPTIONS_KILLPROCESS          32783
#define ID_SP_DEDICATION                32784
#define ID_SP_PROCESS_COUNT             32785
#define ID_SP_COPYRIGHT                 32786
#define ID_SP_PERFORMANCE               32787
#define ID_PRIORITY_REALTIME            32794
#define ID_PRIORITY_HIGH                32795
#define ID_PRIORITY_ABOVENORMAL         32796
#define ID_PRIORITY_NORMAL              32797
#define ID_PRIORITY_BELOWNORMAL         32798
#define ID_PRIORITY_LOW                 32799
#define ID_PRIORITY_DISABLEBOOSTPRIORITY 32800
#define ID_OPTIONS_KILLPROCESS_ALL_INSTANCES -32735
#define ID_UTILS_OPENPARENTFOLDER       32802
#define ID_UTILS_PROPERTIES             32803
#define ID_UTILS_PRIVILEGEMANAGER       32804

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        171
#define _APS_NEXT_COMMAND_VALUE         32807
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
